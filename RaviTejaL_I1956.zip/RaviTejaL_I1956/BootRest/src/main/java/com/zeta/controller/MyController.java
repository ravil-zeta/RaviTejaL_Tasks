package com.zeta.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zeta.output.HandS;
import com.zeta.output.HumanData;
import com.zeta.output.PostClass;
import com.zeta.output.PutClass;
import com.zeta.output.ReqResData;
import com.zeta.services.IMyservice;

//this is my controller
@RestController
public class MyController {

	@Autowired
	IMyservice service;
	
	//to get the data from url
	@RequestMapping(value="/users",method=RequestMethod.GET,
			consumes=MediaType.ALL_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	public ReqResData getAllUsers()
	{
		return service.getAllUsers();
	}
	
	//to get the data from url by id
	@RequestMapping(value="/users/{id}",method=RequestMethod.GET,
			consumes=MediaType.ALL_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	public HandS getUserById(@PathVariable int id)
	{
		return service.getUserById(id);
	}
	
	//to add the user data
	@RequestMapping(value="/api/users",method=RequestMethod.POST,
			consumes=MediaType.ALL_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	public PostClass postData(@RequestBody PostClass pc)
	{
		return service.postData(pc);
	}
	
	//to update the user data
	@RequestMapping(value="/api/users/{id}",method=RequestMethod.PUT,
			consumes=MediaType.ALL_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	public PutClass putData(@RequestBody PutClass pc,@PathVariable int id)
	{
		pc.setId(id);
		return service.putData(pc,id);
	}
}
