package com.zeta.output;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PutClass {
	
	@JsonProperty("id")
	private int id;
	
	@JsonProperty("name")
	private String name;
	
	@JsonProperty("job")
	private String job;
	
	@JsonProperty("updatedAt")
	private String updatedAt;

	public String getName() {
		return name;
	}

	public String getJob() {
		return job;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}