package com.zeta.output;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PostClass {

	@JsonProperty("name")
	private String name;
	
	@JsonProperty("job")
	private String job;
	
	@JsonProperty("id")
	private int id;
	
	@JsonProperty("createdAt")
	private String createdAt;

	public String getName() {
		return name;
	}

	public String getJob() {
		return job;
	}

	public int getId() {
		return id;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	
}