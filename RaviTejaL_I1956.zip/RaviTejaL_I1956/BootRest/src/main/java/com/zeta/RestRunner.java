package com.zeta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

//this is the start
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
public class RestRunner {     

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(RestRunner.class, args);
	}
	
	//here it initializes the rest template
	@Bean
	public RestTemplate template()
	{
		return new RestTemplate();
	}

}
