package com.zeta.output;

import com.fasterxml.jackson.annotation.JsonProperty;

public class HandS {
	
	@JsonProperty("data")
	private HumanData data;
	
	@JsonProperty("support")
	private SupportData support;

	public HumanData getData() {
		return data;
	}

	public SupportData getSupport() {
		return support;
	}

	public void setData(HumanData data) {
		this.data = data;
	}

	public void setSupport(SupportData support) {
		this.support = support;
	}
	
}
