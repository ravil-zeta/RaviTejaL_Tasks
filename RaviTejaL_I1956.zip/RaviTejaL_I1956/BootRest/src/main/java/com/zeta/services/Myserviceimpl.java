package com.zeta.services;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.zeta.output.HandS;
import com.zeta.output.HumanData;
import com.zeta.output.PostClass;
import com.zeta.output.PutClass;
import com.zeta.output.ReqResData;

@Service
public class Myserviceimpl implements IMyservice{

	@Autowired
	RestTemplate template;
	
	//it gets all the users data
	public ReqResData getAllUsers() {
		
		try {
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
            HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

            ResponseEntity response = restTemplate.exchange("https://reqres.in/api/users", HttpMethod.GET,entity,ReqResData.class);

            ReqResData dt=(ReqResData) response.getBody();
            return dt;
        } catch (Exception ex) {
           ex.printStackTrace();
           return null;
        }
	}

	//it gets the user by id
	public HandS getUserById(int id) {
		
		String url="https://reqres.in/api/users/{id}";
		url=url.replace("{id}", String.valueOf(id));
		
		try {
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
            HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

            ResponseEntity response = restTemplate.exchange(url, HttpMethod.GET,entity,HandS.class);
            
            System.out.println(response);
            HandS dt=(HandS) response.getBody();
            return dt;
        } catch (Exception ex) {
           ex.printStackTrace();
           return null;
        }
	}

	//it post the user data
	public PostClass postData(PostClass pc) {
		
		String url="https://reqres.in/api/users";
		
		try {
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
            HttpEntity<Object> entity = new HttpEntity<Object>(pc, headers);

            ResponseEntity response = restTemplate.exchange(url, HttpMethod.POST,entity,PostClass.class);
            
            PostClass dt=(PostClass) response.getBody();
            return dt;
        } catch (Exception ex) {
           ex.printStackTrace();
           return null;
        }
		
	}

	//it updsates the user data
	@Override
	public PutClass putData(PutClass pc,int id) {
		
		String url="https://reqres.in/api/users/{id}";
		url=url.replace("{id}", String.valueOf(id));
		
		try {
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            headers.add("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
            HttpEntity<Object> entity = new HttpEntity<Object>(pc, headers);

            ResponseEntity response = restTemplate.exchange(url, HttpMethod.PUT,entity,PutClass.class);
            
            PutClass dt=(PutClass) response.getBody();
            return dt;
        } catch (Exception ex) {
           ex.printStackTrace();
           return null;
        }
	}

}
