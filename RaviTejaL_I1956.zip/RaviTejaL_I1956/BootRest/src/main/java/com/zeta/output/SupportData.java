package com.zeta.output;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SupportData {
	@JsonProperty("url")
	private String url;
	
	@JsonProperty("text")
	private String text;
}