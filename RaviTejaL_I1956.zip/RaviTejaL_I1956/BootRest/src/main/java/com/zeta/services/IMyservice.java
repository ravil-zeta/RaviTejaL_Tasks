package com.zeta.services;

import com.zeta.output.HandS;
import com.zeta.output.HumanData;
import com.zeta.output.PostClass;
import com.zeta.output.PutClass;
import com.zeta.output.ReqResData;

//this is my abstract view
public interface IMyservice {
	
	public ReqResData getAllUsers();
	public HandS getUserById(int id);
	public PostClass postData(PostClass pc);
	public PutClass putData(PutClass pc,int id);
}
