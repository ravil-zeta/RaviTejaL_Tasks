package com.zeta.helper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//this is my helper class for logging
public class HelperClass {
	
	public static  Logger getZetaLogger(Class c)
	{
		Logger lg=LoggerFactory.getLogger(c);
		return lg;
	}

}
