package com.zeta.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zeta.dao.Mydaorepository;
import com.zeta.model.Loan;

//this is service layer
@Service
public class Myserviceimpl implements IMyservice {
	
	@Autowired
	Mydaorepository dao;
	public List<Loan> getLoans() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	public Loan getLoanById(int lnid) {
		// TODO Auto-generated method stub
		return dao.findOne(lnid);
	}

	public Loan addNewLoan(Loan ln) {
		// TODO Auto-generated method stub
		return dao.save(ln);
	}

	public Loan updateLoan(Loan ln) {
		// TODO Auto-generated method stub
		return dao.save(ln);
	}

	public void deleteLoanById(int lnid) {
		// TODO Auto-generated method stub
		dao.delete(lnid);
	}

	public void deleteAllLoans() {
		// TODO Auto-generated method stub
		dao.deleteAll();
	}

}
