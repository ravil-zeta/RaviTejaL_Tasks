package com.zeta.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

//this is the the model of my loan table
@Entity @Table(name="loan")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Loan {
	
	@Id
	@Column
	private int loan_no;
	@Column
	private String aadhar_no;
	@Column
	private String first_name;
	@Column
	private String last_name;
	@Column
	private double amount;
	@Column
	private Date start_date;
	@Column
	private double tenure;

	public int getLoan_no() {
		return loan_no;
	}
	public String getAadhar_no() {
		return aadhar_no;
	}
	public String getFirst_name() {
		return first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public double getAmount() {
		return amount;
	}
	public Date getStart_date() {
		return start_date;
	}
	public double getTenure() {
		return tenure;
	}
	public void setLoan_no(int loan_no) {
		this.loan_no = loan_no;
	}
	public void setAadhar_no(String aadhar_no) {
		this.aadhar_no = aadhar_no;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public void setTenure(double tenure) {
		this.tenure = tenure;
	}
	
}
