package com.zeta.services;

import java.util.List;

import com.zeta.model.Loan;

public interface IMyservice {
	public List<Loan> getLoans();
	public Loan getLoanById(int lnid);
	public Loan addNewLoan(Loan ln);
	public Loan updateLoan(Loan ln);
	public void deleteLoanById(int lnid);
	public void deleteAllLoans();
}
