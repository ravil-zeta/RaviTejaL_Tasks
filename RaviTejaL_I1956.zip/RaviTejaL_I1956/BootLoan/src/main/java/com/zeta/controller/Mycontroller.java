package com.zeta.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zeta.helper.HelperClass;
import com.zeta.model.Loan;
import com.zeta.services.IMyservice;

//Controller starts here
@RestController
public class Mycontroller {
	
	@Autowired
	IMyservice service;
	
	//to get all loan records
	@GetMapping("/loans/all")
	public List<Loan> getLoans()
	{
		return service.getLoans();
	}
	
	//to get loan details based on id
	@GetMapping("/loans/{id}")
	public Loan getLoanById(@PathVariable int id) {
		
		HelperClass.getZetaLogger(Mycontroller.class).info(this.getClass().getSimpleName() + " - Get Loan by id is invoked.");
		Loan ln=service.getLoanById(id);
		return ln;
	}
	
	//to post new loan record
	@PostMapping("/loans/add")
	public Loan addNewLoan(@RequestBody Loan ln) {
		
		HelperClass.getZetaLogger(Mycontroller.class).info(this.getClass().getSimpleName() + " - add new Loan is invoked.");
		return service.addNewLoan(ln);
	}
	
	//to update any loan record
	@PutMapping("loans/update/{id}")
	public Loan updateLoan(@RequestBody Loan ln, @PathVariable int id) {
		// TODO Auto-generated method stub
		ln.setLoan_no(id);
		return service.updateLoan(ln);
	}
	
	//to delete any loan record
	@DeleteMapping("loans/delete/{id}")
	public void deleteLoanById(@PathVariable int id) {
		// TODO Auto-generated method stub
		service.deleteLoanById(id);
	}
	 
	//to delete all loan records
	@DeleteMapping("loans/deleteall")
	public void deleteAllLoans() {
		// TODO Auto-generated method stub
		service.deleteAllLoans();
	}

}
