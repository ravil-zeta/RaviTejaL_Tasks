package com.zeta.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.hamcrest.Matchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.zeta.dao.Mydaorepository;
import com.zeta.model.Loan;
import com.zeta.services.IMyservice;

//this for testing my controller
@RunWith(MockitoJUnitRunner.class)
public class MyControllerTest {
	
private MockMvc mokMvc;
	
	//this used to convert json to object and vice vers
	ObjectMapper mapper=new ObjectMapper();
	ObjectWriter writer= mapper.writer();
	
	//duplicates service reference
	@Mock
	IMyservice service;
	
	@InjectMocks
	Mycontroller mycontroller;
	
	//creates a loan instructor
	Loan l1=Loan.builder()
			.loan_no(1001)
			.aadhar_no("123456789000")
			.first_name("Goku")
			.last_name("Saien")
			.amount(10000)
			.start_date(Date.valueOf("2024-02-03"))
			.tenure(10).build();
	
	@Before
	public void setup()
	{
		MockitoAnnotations.initMocks(this);
		this.mokMvc= MockMvcBuilders.standaloneSetup(mycontroller).build();
	}
	
	//tests the getLoans
	@Test
	public void getLoansSuccess() throws Exception
	{
		List ln=new ArrayList(Arrays.asList(l1));
		
		System.out.println(ln);
		
		Mockito.when(service.getLoans()).thenReturn(ln);
		
		mokMvc.perform(MockMvcRequestBuilders
	            .get("/loans/all")
	            .contentType(MediaType.APPLICATION_JSON))
	            .andExpect(status().isOk())
	            .andExpect(jsonPath("$", hasSize(1)))
	            .andExpect(jsonPath("$[0].first_name", is("Goku")));
	}
	
	//tests the getloan by id
	@Test
	public void getLoanByIdSuccess() throws Exception
	{

		Mockito.when(service.getLoanById(1001)).thenReturn(l1);
		
		mokMvc.perform(get("/loans/1001")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("first_name").value(l1.getFirst_name()));
	}
	
	//test the adding of new loan
	@Test
	public void addNewLoanSuccess() throws Exception
	{
		Mockito.when(service.addNewLoan(l1)).thenReturn(l1);
		
		String cnt=writer.writeValueAsString(l1);
		
		MockHttpServletRequestBuilder mockRequest = MockMvcRequestBuilders.post("/loans/add")
	            .contentType(MediaType.APPLICATION_JSON)
	            .accept(MediaType.APPLICATION_JSON)
	            .content(cnt);
		
		mokMvc.perform(mockRequest)
        .andExpect(status().isOk());
	}
	
	//tests the updation of loan
	@Test
	public void updateLoanSuccess() throws Exception
	{
		l1.setLoan_no(1001);
		Mockito.when(service.updateLoan(l1)).thenReturn(l1);
		String cnt=writer.writeValueAsString(l1);
		
		MockHttpServletRequestBuilder mockRequest = MockMvcRequestBuilders.put("/loans/update/1001")
	            .contentType(MediaType.APPLICATION_JSON)
	            .accept(MediaType.APPLICATION_JSON)
	            .content(cnt);
		
		mokMvc.perform(mockRequest)
        .andExpect(status().isOk());
	}
	
//	@Test
//	public void deleteLoanByIdSuccess() throws Exception
//	{
//		Mockito.when(service.deleteLoanById(1001)).thenReturn(Optional.of(l1));
//	}
}
